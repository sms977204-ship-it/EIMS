#ifndef EMPSQL_H
#define EMPSQL_H

#include <QObject>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QtDebug>
#include <QSqlQuery>
#include<QCoreApplication>
#include"emptime.h"
struct EmpInfo//emp的属性
{
    int id;
    QString employeeid;
    QString name;
    QString sex;
    quint8  age;
    QString department;
    QString level;
    quint8  moneyrest;
    quint8  rest;
    quint32 wages;
    QString phone;
    QString password;
};

struct UserInfo//user的属性
{
    QString username;
    QString password;
    QString auth;
};
struct LeaveRecord {
    int id;
    QString employeeid;
    QString startDate;
    QString endDate;
    QString reason;
    QString status; // 请假状态，如 "待审批", "已批准", "已拒绝"
};

struct AttendanceRecord {
    int id;
    QString employeeid;
    QString date;
    QString punchInTime;
    QString punchOutTime;
};
class empSql : public QObject
{
    Q_OBJECT
public:
    explicit empSql(QObject *parent = nullptr);

    static empSql *ptrempSql;//声明静态指针
    static empSql *getinstance()
    {
        if(nullptr == ptrempSql)
        {
            ptrempSql = new empSql;
        }
        return ptrempSql;
    }//初始化静态指针

    //打开数据库
    void OpenDatabase();

    //查询所有雇员数量
    quint32 getEmpCnt();

    //查询第几页雇员那个数据
    QList<EmpInfo> getPageEmp(quint32 page,quint32 uiCnt);

    //增加雇员
    bool addEmp(EmpInfo info);
    bool addEmpex(QList<EmpInfo> l);

    //删除雇员
    bool delEmp(int id);

    //清空雇员表
    bool claerEmpTable();

    //查询员工
    bool eisExit(QString strUser);

    //修改雇员信息
    bool UpdateEmpInfo(EmpInfo info);

    //查询所有用户,页数从0开始
    QList<UserInfo> getAllUser();

    //修改用户权限
    bool changeuserAut(UserInfo info);

    //查询用户是否存在
    bool isExitUser(QString strUser,QString strpw);

    //添加单个用户
    bool AddUser(UserInfo info);

    //删除单个用户
    bool delUser(QString strUserName);

    //查找用户名
    bool isExitUser(QString strUser);


    bool addLeaveRecord(const LeaveRecord& record);
    bool updateLeaveStatus(int id, const QString& status);
    QList<LeaveRecord> getLeaveRecords(const QString& employeeid = "");
    bool addPunchInRecord(const QString& employeeid, const QString& date, const QString& punchInTime);
    bool addPunchOutRecord(const QString& employeeid, const QString& date, const QString& punchOutTime);
    AttendanceRecord getAttendanceRecord(const QString& employeeid, const QString& date);
    QList<AttendanceRecord> getAttendanceRecords(const QString& employeeid = "", const QString& startDate = "", const QString& endDate = "");
    // 检查是否已经上班打卡
    bool hasPunchedIn(const QString& employeeid, const QString& date);
    // 检查是否已经下班打卡
    bool hasPunchedOut(const QString& employeeid, const QString& date);
    // 获取个人请假记录
    QList<LeaveRecord> getPersonalLeaveRecords(const QString& employeeid);
    // 获取个人考勤记录
    QList<AttendanceRecord> getPersonalAttendanceRecords(const QString& employeeid, const QString& startDate = "", const QString& endDate = "");

signals:

private:
    QSqlDatabase m_db;
};

#endif // EMPSQL_H
