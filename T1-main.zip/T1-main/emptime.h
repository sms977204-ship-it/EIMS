#ifndef EMPTIME_H
#define EMPTIME_H


class empTime
{
public:
    empTime();
    double days(double i);
    double hours(double i);
};

#endif // EMPTIME_H
